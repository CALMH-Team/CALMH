package org.calmh.server.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;

import org.calmh.server.data.Disaster;
import org.calmh.server.data.DisasterRepository;
import org.calmh.server.util.CouchDatabase;
import org.calmh.server.util.JsonErrorMessage;
import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;
import org.ektorp.ViewResult.Row;

@ApplicationPath("/rest")
@Path("/disaster")
public class DisasterService extends Application {
	
	static final String simpleDateFormat = "yyyy-MM-DD";
	
	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Response getDisaster(@PathParam("id") String id) {
		
		CouchDbConnector dbconn = CouchDatabase.getInstance();

		ResponseBuilder builder;
		try {
			Disaster disaster = dbconn.get(Disaster.class, id);
			builder = Response.ok(disaster.objectToJson(disaster));
		} catch (DocumentNotFoundException e) {
			builder = Response.status(404);
		} catch (Exception e) {
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}
	
	@GET
	@Path("/all")
	@Produces("application/json")
	public Response getAllDisasters() {
		
		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		try {
			DisasterRepository disasterRepo = new DisasterRepository(dbconn);
			
			List<Row> disastersBulk = disasterRepo.getListOfDisasters();
			int cnt = 0;
			int bulkSize = disastersBulk.size();
			if (bulkSize > 0) {
				String result = "[";
				for (Row row : disastersBulk) {
					Disaster disaster = dbconn.get(Disaster.class, row.getId());
					result = result + disaster.objectToJson(disaster);
					// append , between json user objects, but not on the last one
					if (cnt < bulkSize - 1) {
						result = result + ",";
					}
					cnt++;
				}
				result = result + "]";
				builder = Response.ok(result);
			} else {
				builder = Response.status(404);
			}

		} catch(Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{\"Error\": \"" + JsonErrorMessage.escapeMessage(e.getLocalizedMessage()) + "\"}");
		}

		return builder.build();
	}
	
	@POST
	@Produces("application/json")
	public Response createDisaster(@Context UriInfo info,
			@FormParam("location") String location,
			@FormParam("date") String date,
			@FormParam("disastertype") String disastertype) {
		
		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		try {
			Disaster disaster = new Disaster();
			disaster.setType(Disaster.typeValue);
			
			SimpleDateFormat formatter = new SimpleDateFormat(simpleDateFormat);
			
			if (location != null && !location.isEmpty()) {
				// try if post is form encoded
				disaster.setLocation(location);
				disaster.setDate(formatter.parse(date));
				disaster.setDisasterType(disastertype);		
			} else {
				// try query params
				disaster.setLocation(info.getQueryParameters().getFirst("location"));
				disaster.setDate(formatter.parse(info.getQueryParameters().getFirst("date")));
				disaster.setDisasterType(info.getQueryParameters().getFirst("disastertype"));	
			}
			
			dbconn.create(disaster);
			
			// get user again to return full json
			disaster = dbconn.get(Disaster.class, disaster.getId());
			builder = Response.status(201).entity(disaster.objectToJson(disaster));
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}
		
		return builder.build();
	}

	@PUT
	@Path("/{id}")
	@Produces("application/json")
	public Response updateDisaster(@PathParam("id") String id, InputStream is) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		
		ResponseBuilder builder = null;
		
		try {
			String jsonInput = readFromStream(is);
			
			Disaster disaster = new Disaster();
			disaster.jsonToObject(jsonInput, Disaster.class);
			dbconn.update(disaster);
			
			disaster = dbconn.get(Disaster.class, disaster.getId());
			builder = Response.ok(disaster.objectToJson(disaster));
		} catch (DocumentNotFoundException dnfe) {
			builder = Response.status(404);
		} catch (Exception e) {
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}

	private String readFromStream(InputStream stream) throws IOException {
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1000]; 
		int wasRead = 0;
		do {
			wasRead = stream.read(buffer); 
			if (wasRead > 0) {
				baos.write(buffer, 0, wasRead);
			}
		} while (wasRead > -1);
		
		return new String(baos.toByteArray()); 
	}

	@DELETE
	@Path("/{id}")
	@Produces("application/json")
	public Response deleteDisaster(@PathParam("id") String id) {
		
		CouchDbConnector dbconn = CouchDatabase.getInstance();

		ResponseBuilder builder = null;
		try {
			Disaster disaster = dbconn.get(Disaster.class, id);
			dbconn.delete(disaster.getId(), disaster.getRevision());
			builder = Response.ok(disaster.objectToJson(disaster));
		} catch (DocumentNotFoundException e) {
			builder = Response.status(404);
		} catch (Exception e) {
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}
	
}