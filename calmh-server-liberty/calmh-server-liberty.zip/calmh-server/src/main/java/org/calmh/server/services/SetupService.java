package org.calmh.server.services;

import java.util.Date;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.calmh.server.data.Disaster;
import org.calmh.server.data.Disaster.DisasterType;
import org.calmh.server.data.User;
import org.calmh.server.data.User.UserType;
import org.calmh.server.util.CouchDatabase;
import org.ektorp.CouchDbConnector;

@ApplicationPath("/rest")
@Path("/setup")
public class SetupService extends Application {

	@GET
	@Path("/samplevalues")
	@Produces("application/json")
	public Response setupSampleValues() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		
		/*
		 * Create sample data to test and play with the application
		 */
		
		Disaster event;

		event = new Disaster();
		event.setLocation("Haiti");
		event.setDate(new Date());
		event.setDisasterType(DisasterType.TORNADO.getDescription());
		dbconn.create(event);
		
		event = new Disaster();
		event.setLocation("Aceh province, Sumatra, Indonesia");
		event.setDate(new Date());
		event.setDisasterType(DisasterType.TSUNAMI.getDescription());
		dbconn.create(event);
		
		event = new Disaster();
		event.setLocation("New Orleans, Louisinia, USA");
		event.setDate(new Date());
		event.setDisasterType(DisasterType.HURRICANE.getDescription());
		dbconn.create(event);
		
		User user;

		user = new User();
		user.setType(UserType.PATIENT.getDescription());
		user.setUsername("aroos");
		user.setPassword("aroos");
		user.setFirstname("Arie");
		user.setLastname("Roos");
		user.setEmail("aroos@gmail.com");
		dbconn.create(user);
		
		user = new User();
		user.setType(UserType.PATIENT.getDescription());
		user.setUsername("bevers");
		user.setPassword("bevers");
		user.setFirstname("Bob");
		user.setLastname("Evers");
		user.setEmail("bevers@yahoo.com");
		dbconn.create(user);
		
		ResponseBuilder builder = Response.ok("{}");
        return builder.build();
	}
	
	@GET
	@Path("/initvalues")
	@Produces("application/json")
	public Response setupInitialValues() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		
		/*
		 * Create admin account and other initial data that is needed for the application
		 */
		
		User user;

		user = new User();
		user.setType(UserType.ADMIN.getDescription());
		user.setUsername("admin");
		user.setPassword("admin");
		user.setFirstname("System");
		user.setLastname("Administrator");
		user.setEmail("admin@calmh.org");
		dbconn.create(user);
		
		user = new User();
		user.setType(UserType.ADMIN.getDescription());
		user.setUsername("useradmin");
		user.setPassword("useradmin");
		user.setFirstname("User System");
		user.setLastname("Administrator");
		user.setEmail("useradmin@calmh.org");
		dbconn.create(user);
		
		ResponseBuilder builder = Response.ok("{}");
        return builder.build();
	}

}