package org.calmh.server.data;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.GenerateView;

public class DisasterRepository extends CouchDbRepositorySupport<Disaster> {

    public DisasterRepository(CouchDbConnector dbconn) {
            super(Disaster.class, dbconn);
    }

    public List<Disaster> findByDisasterType(String type) {
    	//return queryView("by_name", name);
    	return null;
    }
    
    @GenerateView
    public List<Disaster> findByLocation(String location) {
        return queryView("by_location", location);
    }
    
}