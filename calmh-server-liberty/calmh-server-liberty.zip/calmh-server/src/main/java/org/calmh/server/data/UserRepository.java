package org.calmh.server.data;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.GenerateView;

public class UserRepository extends CouchDbRepositorySupport<User> {

    public UserRepository(CouchDbConnector db) {
            super(User.class, db);
    }

    public List<User> findByUserName(String userName) {
    	//return queryView("by_usernamer", userName);
    	return null;
    }
    
    @GenerateView
    public List<User> findByType(String type) {
        return queryView("by_type", type);
    }
    
}