package org.calmh.server.data;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.ViewResult;
import org.ektorp.ViewResult.Row;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.GenerateView;
import org.ektorp.support.View;

@View(name = "all", map = "function(doc) { if (doc.type && doc.type == 'user' ) emit( null, doc._id ) }")
public class UserRepository extends CouchDbRepositorySupport<User> {

    public UserRepository(CouchDbConnector dbconn) {
            super(User.class, dbconn);
    }
    
    public List<Row> getListOfUsers() {
    	/* 
    	 	{	"_id": "_design/User",
  				"views": {
    				"getAll": {
      					"map": "function(doc) { \n  if (doc.type && doc.type == 'user' ) emit( null, doc._id )\n}"
    				}
  				}
			}
    	 */
        ViewResult vr = db.queryView(createQuery("getAll"));
        return vr.getRows();
    }
    
    public int getNumberOfUsers() {
        ViewResult vr = db.queryView(createQuery("getAll"));
        return vr.getSize();
    }
    
    @GenerateView
    public List<User> findByType(String type) {
        return queryView("by_type", type);
    }
    
}