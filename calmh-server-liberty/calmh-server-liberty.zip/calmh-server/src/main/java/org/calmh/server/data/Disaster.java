package org.calmh.server.data;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A disaster is a sudden, calamitous event 
 * that seriously disrupts the functioning of a community or society and causes human, material, 
 * and economic or environmental losses that exceed the community's or society's ability to cope 
 * using its own resources. Though often caused by nature, disasters can have human origins.
 *
 */
public class Disaster extends BaseDocument {
		
	@JsonIgnore
	private static final long serialVersionUID = -8004662436417913528L;
	
	public enum DisasterType {
		TSUNAMI("tsunami"),
		EARTHQUAKE("earthquake"),
	    TORNADO("tornado"),
	    HURRICANE("hurricane"),
	    FLOOD("flood"),
	    WILDFIRE("wildfire"),
	    DROUGHT("drought");
	    
	    private String description;

	    DisasterType(String description) {
	        this.description = description;
	    }

	    public String getDescription() {
	        return this.description;
	    }
	}
	
	@JsonIgnore
	private static final String typeValue = "disaster";
	
	private String type;
	private String location;
	private Date date;
	private String disasterType;
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = typeValue;
	}
	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDisasterType() {
		return disasterType;
	}

	public void setDisasterType(String disasterType) {
		this.disasterType = disasterType;
	}

}
