package org.calmh.server.util;

import java.net.MalformedURLException;
import java.net.URL;

import com.cloudant.client.api.ClientBuilder;
import com.cloudant.client.api.CloudantClient;

public class CloudantDatabase {

	private static CloudantClient clientconn = null;

	public static CloudantClient instance() {
		if (clientconn != null) {
			return clientconn;
		}

		synchronized (CloudantDatabase.class) {
			URL url = null;
			try {
				// URL format https://username:password@hostname:port
				url = new URL("https://e1bf4e40-2414-4915-a03f-9f9dc272373c-bluemix:08ded91c4ea922069502e43626dca51deecfbfc3f2d5ba8eda27da6c5bc17988@e1bf4e40-2414-4915-a03f-9f9dc272373c-bluemix.cloudantnosqldb.appdomain.cloud");
			} catch (MalformedURLException e) {
				throw new RuntimeException(e);
			}
						
			ClientBuilder builder = ClientBuilder.url(url);
			clientconn = builder.build();
			return clientconn;
		}
	  
	}
}
