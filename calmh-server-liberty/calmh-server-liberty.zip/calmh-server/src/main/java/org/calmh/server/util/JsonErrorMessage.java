package org.calmh.server.util;

public class JsonErrorMessage {

	static public String escapeMessage(String msg) {
		return msg.replace("\"", "\\\"");
	}
}
