package org.calmh.server.services;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.calmh.server.data.User;
import org.calmh.server.util.CouchDatabase;
import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;

@ApplicationPath("/rest")
@Path("/auth")
public class AuthService extends Application {
	
	static final String loginFailed = "{Error: \"Login failed.\"}";

	@GET
	@Path("/login/{id}/{pw}")
	@Produces("application/json")
	public Response login(@PathParam("id") String id, @PathParam("pw") String pw) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		
		ResponseBuilder builder = null;
		try {
			User user = dbconn.get(User.class, id);
			
			if (user.getPassword().equals(pw)) {
				builder = Response.ok(user.objectToJson(user));
			} else {
				builder = Response.status(401).entity(loginFailed);
				
			}
		} catch (DocumentNotFoundException e) {
			builder = Response.status(401).entity(loginFailed);
		}
		
        return builder.build();
	}
	
}