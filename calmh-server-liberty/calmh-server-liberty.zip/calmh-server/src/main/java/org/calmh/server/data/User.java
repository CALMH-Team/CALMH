package org.calmh.server.data;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class User extends BaseDocument {
	
	public enum UserType {
		PATIENT("patient"),
		ADMIN("admin"),
	    VOLUNTEER("volunteer");
	    
	    private String name;

	    UserType(String name) {
	        this.name = name;
	    }

	    public String getName() {
	        return this.name;
	    }
	}
	
	@JsonIgnore
	private static final long serialVersionUID = 6979349165525709637L;
	
	@JsonIgnore
	public static final String typeValue = "user";
	
	private String type;
	private String usertype;
	private String username;
	private String password;
	private String firstname;
	private String lastname;
    private String email;

    
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = typeValue;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = UserType.PATIENT.getName();
		// make sure the user type is a known one
		for (UserType ut : UserType.values()) {
	        if (ut.getName().equals(usertype)) {
	        	this.usertype = usertype;
	        }
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
