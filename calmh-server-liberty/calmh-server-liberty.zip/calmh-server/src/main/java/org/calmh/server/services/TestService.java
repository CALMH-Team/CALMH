package org.calmh.server.services;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.calmh.server.util.CloudantDatabase;
import org.calmh.server.util.CouchDatabase;
import org.ektorp.CouchDbConnector;

import com.cloudant.client.api.CloudantClient;

@ApplicationPath("/rest")
@Path("/test")
public class TestService extends Application {

	@GET
	@Path("/ping")
	@Produces("application/json")
	public Response doPing() {

		ResponseBuilder builder = Response.ok("{\"calmh app\": \"alive\"}");
        return builder.build();
	}

	@GET
	@Path("/getCloudantDatabases")
	@Produces("application/json")
	public Response getCloudantDatabases() {

		CloudantClient client = CloudantDatabase.instance();

		String databases = "";
		for (String db : client.getAllDbs()) {
			databases = databases + db + " ";
		}
		
		ResponseBuilder builder = Response.ok("{\"databases\": \"" + databases + "\"}");
        return builder.build();
	}

	@GET
	@Path("/getCouchDatabase")
	@Produces("application/json")
	public Response getCouchDatabase() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();

		ResponseBuilder builder = Response.ok("{\"databasename\": \"" + dbconn.getDatabaseName() + "\"}");
        return builder.build();
	}

}