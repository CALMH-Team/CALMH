package org.calmh.server.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;

import org.calmh.server.data.User;
import org.calmh.server.data.User.UserType;
import org.calmh.server.data.UserRepository;
import org.calmh.server.util.CouchDatabase;
import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;

@ApplicationPath("/rest")
@Path("/user")
public class UserService extends Application {

	static final String simpleDateFormat = "yyyy-MM-DD";

	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Response getUser(@PathParam("id") String id) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder;
		
		try {
			User user = dbconn.get(User.class, id);
			builder = Response.ok(user.objectToJson(user));
		} catch (DocumentNotFoundException dnfe) {
			builder = Response.status(404);
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}

	@GET
	@Path("/all")
	@Produces("application/json")
	public Response getAllUsers() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		UserRepository userRepo = new UserRepository(dbconn);
		List<User> usersBulk = userRepo.getAll();
		int cnt = 0;
		if (usersBulk.size() > 0) {
			String result = "[";
			for (User user : usersBulk) {
				result = result + user.objectToJson(user);
				if (cnt < usersBulk.size()) {
					result = result + ",";
				}
			}
			result = result + "]";
			builder = Response.ok(result);
		} else {
			builder = Response.status(404);
		}

		return builder.build();
	}

	@POST
	@Path("/new")
	@Produces("application/json")
	public Response createUser(@Context UriInfo info,
								@FormParam("usertype") String usertype,
								@FormParam("username") String username,
								@FormParam("password") String password,
								@FormParam("firstname") String firstname,
								@FormParam("lastname") String lastname,
								@FormParam("email") String email) {
		
		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		try {
			User user = new User();
			user.setType(User.typeValue);
			
			if (usertype != null && !usertype.isEmpty()) {
				// try if post is form encoded
				user.setUsertype(usertype);
				user.setUsername(username);
				user.setPassword(password);
				user.setFirstname(firstname);
				user.setLastname(lastname);
				user.setEmail(email);		
			} else {
				// try query params
				user.setUsertype(info.getQueryParameters().getFirst("usertype"));
				user.setUsername(info.getQueryParameters().getFirst("username"));
				user.setPassword(info.getQueryParameters().getFirst("password"));
				user.setFirstname(info.getQueryParameters().getFirst("firstname"));
				user.setLastname(info.getQueryParameters().getFirst("lastname"));
				user.setEmail(info.getQueryParameters().getFirst("email"));		
			}
			
			dbconn.create(user);
			
			// get user again to return full json
			user = dbconn.get(User.class, user.getId());
			builder = Response.status(201).entity(user.objectToJson(user));
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}
		
		return builder.build();
	}

	@PUT
	@Path("/{id}")
	@Produces("application/json")
	public Response updateUser(@PathParam("id") String id, InputStream is) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		try {
			String jsonInput = readFromStream(is);
			
			User user = new User();
			user.jsonToObject(jsonInput, User.class);
			dbconn.update(user);
			
			user = dbconn.get(User.class, user.getId());
			builder = Response.ok(user.objectToJson(user));
		} catch (DocumentNotFoundException dnfe) {
			builder = Response.status(404);
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}

	private String readFromStream(InputStream stream) throws IOException {
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1000]; 
		int wasRead = 0;
		do {
			wasRead = stream.read(buffer); 
			if (wasRead > 0) {
				baos.write(buffer, 0, wasRead);
			}
		} while (wasRead > -1);
		
		return new String(baos.toByteArray()); 
	}

	@DELETE
	@Path("/{id}")
	@Produces("application/json")
	public Response deleteUser(@PathParam("id") String id) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder = null;
		
		try {
			User user = dbconn.get(User.class, id);
			dbconn.delete(user.getId(), user.getRevision());
			builder = Response.ok(user.objectToJson(user));
		} catch (DocumentNotFoundException e) {
			builder = Response.status(404);
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400).entity("{Error: \"" + e.getLocalizedMessage() + "\"}");
		}

		return builder.build();
	}

	@GET
	@Path("/testCreateAndGetUser")
	@Produces("application/json")
	public String testCreateAndGetUser() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();

		User user = new User();
		user.setType(User.typeValue);
		user.setType(UserType.PATIENT.getName());
		user.setUsername("aroos");
		user.setPassword("aroos");
		user.setFirstname("Arie");
		user.setLastname("Roos " + new SimpleDateFormat(simpleDateFormat).format(new Date()));
		user.setEmail("aroos@gmail.com");

		dbconn.create(user);
		String id = user.getId();

		user = dbconn.get(User.class, id);

		return user.objectToJson(user);
	}

	@GET
	@Path("/testCreateAndGetUserRepo")
	@Produces("application/json")
	public String testCreateAndGetUserRepo() {

		CouchDbConnector dbconn = CouchDatabase.getInstance();

		User user = new User();
		user.setType(User.typeValue);
		user.setType(UserType.PATIENT.getName());
		user.setUsername("bevers");
		user.setPassword("bevers");
		user.setFirstname("Bob");
		user.setLastname("Evers " + new SimpleDateFormat(simpleDateFormat).format(new Date()));
		user.setEmail("bevers@yahoo.com");

		UserRepository userRepo = new UserRepository(dbconn);
		userRepo.add(user);

		User user2 = userRepo.get(user.getId());
		return user.objectToJson(user2);
	}

	@Path("/getUsersByType/{type}")
	@Produces("application/json")
	public Response getUsersByLanguage(@PathParam("type") String type) {

		CouchDbConnector dbconn = CouchDatabase.getInstance();
		ResponseBuilder builder;

		String result = "{}";
		UserRepository userRepo = new UserRepository(dbconn);
		try {
			List<User> users = userRepo.findByType(type);
			for (User user : users) {
				result = result + user.objectToJson(user);
			}
		} catch (DocumentNotFoundException dnfe) {
			builder = Response.status(404).entity("{}");
			return builder.build();
		} catch (Exception e) {
			e.printStackTrace();
			builder = Response.status(400);
		}

		builder = Response.ok(result);
		return builder.build();
	}

}