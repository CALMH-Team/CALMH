package org.calmh.server.util;

import javax.naming.InitialContext;

import org.ektorp.CouchDbConnector;
import org.ektorp.CouchDbInstance;
import org.ektorp.http.HttpClient;
import org.ektorp.http.StdHttpClient;
import org.ektorp.impl.StdCouchDbInstance;

/**
 * Singleton to retrieve the CouchDB database connector from JNDI or through
 * URL.
 */
public class CouchDatabase {

	private static final String DATABASE_JNDI = "java:comp/env/couchdb/connector";
	private static final String DATABASE_URL = "http://localhost:5984";
	private static final String DATABASE_USER = "calmh";
	private static final String DATABASE_PASSWORD = "calmh";
	private static final String DATABASE_NAME = "calmh";
	private static final String DATABASE_CONNECT_BY_URL = "URL";
	private static final String DATABASE_CONNECT_BY_JNDI = "JNDI";
	private static final String DATABASE_CONNECT_BY = DATABASE_CONNECT_BY_URL; // switch between URL and JNDI

	private static CouchDbConnector dbconn = null;

	public static CouchDbConnector getInstance() {
		if (dbconn != null) {
			return dbconn;
		}

		if (DATABASE_CONNECT_BY.equals(DATABASE_CONNECT_BY_URL)) {
			return getInstanceByUrl();
		} else {
			return getInstanceByJndi();
		}
	}

	private static CouchDbConnector getInstanceByJndi() {
		synchronized (CouchDatabase.class) {
			try {
				CouchDbInstance db_lookup = (CouchDbInstance) new InitialContext().lookup(DATABASE_JNDI);
				dbconn = db_lookup.createConnector(DATABASE_NAME, true);
				return dbconn;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	private static CouchDbConnector getInstanceByUrl() {
		synchronized (CouchDatabase.class) {
			try {
				HttpClient httpClient = new StdHttpClient.Builder().url(DATABASE_URL).username(DATABASE_USER)
						.password(DATABASE_PASSWORD).build();
				CouchDbInstance dbInstance = new StdCouchDbInstance(httpClient);
				dbconn = dbInstance.createConnector(DATABASE_NAME, true);
				return dbconn;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

}