package org.calmh.server.data;

import java.io.IOException;

import org.ektorp.support.CouchDbDocument;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class BaseDocument extends CouchDbDocument {

	@JsonIgnore
	private static final long serialVersionUID = -4490745512774503918L;
	
	@JsonIgnore
	public String objectToJson(Object obj) {

		String response = "{}";

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
		mapper.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
		mapper.setSerializationInclusion(Include.NON_EMPTY);
		try {
			response = mapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			response = "{\"error\": \"" + e.getMessage() + "\"}";
			e.printStackTrace();
		}

		return response;
	}
	
	@JsonIgnore
	public <T> String jsonToObject(String content, Class<T> valueType) {

		String response = "{}";

		ObjectMapper mapper = new ObjectMapper();
		
		try {
			mapper.readValue(content, valueType);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		return response;
	}
	
}
